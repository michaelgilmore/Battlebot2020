You can use this java applet on your own web pages, but only if the  following
rules are followed:

* The applet should not be used for any commercial purposes. If you want to use
  the applet commercially you should contact me (E-Mail: B.Postma@HetNet.nl).
* The applet should not be changed.
* A reference to my webpage "http://www.brianpostma.com" must be added to your 
  page.


